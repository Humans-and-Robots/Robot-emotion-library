Comments:

- Python can call the c just like node js
- The api.py has the wrapper code
- The main.cpp is pure C++

- test.py is a sample python script that uses the api module. (most of it is commented out, it should be self-explanatory what most of it does.) 

- The module can play an action, turn walking on/off, set the forward velocity with WalkMove and the angular velocity with WalkTurn, and get and set the goal positions of individual motors via GetMotorValue and SetMotorValue.

To do:
1) Copy the entire folder at /home/pi/HROS1-Framework/Linux/project/node_server/api_wrapper to /home/pi/HROS1-Framework/Linux/project/api_wrapper2/api_wrapper2

* You can use the “$sudo cp -r” command

** This will create a new folder called api_wrapper2 in the /Linux/project/ directory. It will also copy the api_wrapper folder from the /project/node_server/ directory and rename it to api_wrapper2

2) Replace the main.cpp in that folder with the main.cpp in the provided .zip and run make

3) You should be able to import the api.py module no matter where it is located and it should work.


—-Created by Ryan McCampbell